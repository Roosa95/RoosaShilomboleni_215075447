# JavaScript Chatbot 

This is a very simple "chatbot" using nothing but JavaScript, HTML, & CSS. I put this in quotes because chatbots these days are way more complex - this is an exercise in vanilla JS loops and conditionals, not AI.

I hope it makes a good intro for anyone interested in chatbots and frontend fundamentals.

Enjoy!

[Demo](https://sylviapap.github.io/chatbot/)

[Blog post](https://dev.to/sylviapap/make-a-simple-chatbot-with-javascript-1gc)
